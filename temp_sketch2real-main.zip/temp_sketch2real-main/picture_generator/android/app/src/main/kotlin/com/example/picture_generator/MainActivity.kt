package com.example.picture_generator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
